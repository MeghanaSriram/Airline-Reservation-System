import sqlite3 as sq

"users.db"
cn = sq.connect("users.db")
c = cn.cursor()
class PPNotFound(Exception):
    "Raised when input user is not found"
    pass
def display_ticket():
    pp_id = int(input("Enter Passport Number "))
    destn = input("Enter Destination ")
    try:
        k = c.execute('''
            select *from users where pp_no == ?
        ''',[pp_id]).fetchall()
        if k:
            print("              **** Ticket ****  ")
            print("         Name            ", k[0][7])
            print("         Passport Number ", k[0][0])
            print("         Flight Id       ", k[0][1])
            print("         Destination     ", k[0][2])
            print("         Date            ", k[0][3])
            print("         Class           ", k[0][4])
            print("         Bill            ", k[0][5])
            print("         Contact Number  ", k[0][6])
        else:
            raise PPNotFound
    except PPNotFound:
        print("Users Not found on entered Passport Number")
        return


