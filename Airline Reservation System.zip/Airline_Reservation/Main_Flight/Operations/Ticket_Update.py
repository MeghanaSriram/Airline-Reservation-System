import sqlite3 as sq

"users.db"
cn = sq.connect("users.db")
c = cn.cursor()

def update_info():
    a_id = "admin"
    a_cid = input("Enter Admin Password to Cancel the Ticket ")
    if a_cid == a_id:
        print('''
        Enter Your choice to Update
        1. Passport Number
        2. Name
        3. Contact NUmber
        4. Return
        ''')
        x = int(input())
        f = int(input("Enter flight id for which ticket has booked "))
        if x == 1 :
            p = int(input("Enter Passport Number "))
            cn.execute('''
                update users set pp_no == ? where f_id == ?
            ''',(p,f))
            print("Passport Number Updated Successfully !!")
        elif x == 2:
            p = input("Enter Name ")
            cn.execute('''
                        update users set name == ? where f_id == ?
                    ''', (p, f))
            print("Name Updated Successfully !!")
        elif x == 3 :
            p = int(input("Enter Contact Number "))
            cn.execute('''
                        update users set cont == ? where f_id == ?
                ''', (p, f))
            print("Contact Number Updated Successfully !!")
        elif x == 4:
            return
        cn.commit()
        return
    else:
        print("Invalid Admin Login Credentials")
        return