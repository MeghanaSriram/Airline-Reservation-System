import sqlite3 as sq

"flights.db"
conn = sq.connect("flights.db")
c = conn.cursor()

"users.db"
cn = sq.connect("users.db")

def book_ticket():
    print(' Airline Reservation')
    name = input("Enter Name ")
    try:
        age = int(input("Enter Age "))
    except ValueError:
        print("Incorrect Input format! Input expected integer Only ")
        return
    gender = input("Enter Gender ")
    try:
        pp_no = int(input("Enter Passport No. "))
    except ValueError:
        print("Incorrect Input format! Input expected integer Only ")
        return
    addr = input("Enter Address  ")
    try:
        cont = int(input("Enter Contact No. "))
    except ValueError:
        print("Incorrect Input format! Input expected integer Only ")
        return
    destn = input("Enter Destination ")

    c.execute('''
        select f_id,f_name,date,class,bill from flights where destination == ? and b_seats <= T_seats
        ''',[destn])
    res = c.fetchall()
    print(res)
    b_fid = int(input("Enter flight id to book the ticket"))

    for i in res:
        if i[0] == b_fid:
            k = c.execute('''
             select T_seats,b_seats from flights where f_id == ?
            ''',[b_fid])
            m=k.fetchall()
            print(m)
            T_seats = m[0][0]
            b_seats = m[0][1]

            if T_seats > b_seats:
                conn.execute('''
                            update flights set b_seats = b_seats + 1 where f_id == ?
                            ''',[b_fid])
                print("Reservation Successful !!")
                data = {}

                data['pp_no'] =pp_no
                data['f_id'] = b_fid
                data['destination'] = destn
                data['date'] = i[2]
                data['class'] = i[3]
                data['bill'] = i[4]
                data['cont'] = cont
                data['name'] = name

                cn.execute('''
                      insert into users(pp_no,f_id,destination,date,class,bill,cont,name) values(?,?,?,?,?,?,?,?)
                    ''', (data.get('pp_no'), data.get('f_id'), data.get('destination'), data.get('date'), data.get('class'),
                          data.get('bill'), data.get('cont'),data.get('name'))
                )
                cn.commit()
                conn.commit()
            else:
                conn.execute('''
                         update flights set b_seats = 0 where f_id == ?
                     ''', [b_fid])
                cn.execute(''' delete from users where f_id = ? ''', [b_fid])
                print("No seats available, Reservation Unsuccessful !!")
                cn.commit()
                conn.commit()
            return
    print("Flight id doesnot match")
    return





