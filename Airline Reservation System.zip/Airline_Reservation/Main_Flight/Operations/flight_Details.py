import sqlite3 as sq

"flights.db"
conn = sq.connect("flights.db")

def get_flightDetails():
    records = conn.execute("select * from flights")
    print(records)
    for i in records:
        print(i)
