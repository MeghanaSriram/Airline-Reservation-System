import sqlite3 as sq

"flights.db"
conn = sq.connect("flights.db")
print(conn)

"users.db"
cn = sq.connect("users.db")

class PPNotFound(Exception):
    "Raised when input user is not found"
    pass

def cancel_ticket():
    a_id = "admin"
    a_cid = input("Enter Admin Password to Cancel the Ticket ")
    if a_cid == a_id:
        pp_no = int(input("Enter Passport number for which ticket was booked "))
        f_id = int(input("Enter flight id to cancel booking"))

        try:
            k = cn.execute('''
                select f_id from users where f_id == ? and pp_no == ?
            ''', (f_id,pp_no)).fetchall()
            if k:
                cn.execute('''delete from users where pp_no = ? ''', [pp_no])
                conn.execute(''' update flights set b_seats = b_seats - 1 where f_id == ? ''', [f_id])
                print("Ticket Cancellation Successful !!")
                conn.commit()
                cn.commit()
                return
            else:
                raise PPNotFound
        except PPNotFound:
            print("Users Not found on entered Passport Number")
            return
    else:
        print("Invalid Admin Credentials")
        return
